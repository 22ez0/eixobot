import { bootstrap } from "#base";

await bootstrap({ meta: import.meta });
